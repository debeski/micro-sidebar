# Micro Sidebar

A reusable Django sidebar app for Web Apps.

## Requirements

-   **Django**: >= 5.1
-   **Bootstrap**: 5 (Required for consistent styling)

## Installation

1.  **Install the package:**
    ```bash
    pip install micro-sidebar
    ```

2.  **Add to `INSTALLED_APPS`:**
    In your `settings.py`:
    ```python
    INSTALLED_APPS = [
        ...
        'sidebar',
        ...
    ]
    ```

3.  **Configure URLs:**
    In your project's `urls.py`:
    ```python
    from django.urls import path, include

    urlpatterns = [
        ...
        path('sidebar/', include('sidebar.urls')),
        ...
    ]
    ```

4.  **Add to your Base Template:**
    In your `base.html` (or equivalent), include the sidebar. It is designed to sit on the left (or right in RTL) of your main content. 
    
    Example structure using Flexbox:
    ```html
    <body>
        <div class="d-flex">
            <!-- Sidebar -->
            {% include "sidebar/content.html" %}

            <!-- Main Content -->
            <div class="flex-grow-1">
                {% block content %}{% endblock %}
            </div>
        </div>
        
        <!-- Bootstrap JS (Required) -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    </body>
    ```

## Customization

### Overriding Content
The sidebar comes with a default template. To customize the links and content, create a file named `content.html` inside `templates/sidebar/` in your project's `templates` directory.

**Path:** `your_project/templates/sidebar/content.html`

The default sidebar logic expects specific classes like `.list-group-item` and `.accordion-item` for the collapsible features to work correctly with the provided JS.

### Positioning
The sidebar is sticky by default. If your app has a top navigation bar (titlebar), the sidebar will automatically adjust its position below it on small screens. If no titlebar is detected, it will stick to the top of the viewport.
